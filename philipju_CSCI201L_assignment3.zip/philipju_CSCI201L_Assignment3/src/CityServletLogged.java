

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import csci201.City;


@WebServlet("/CityServletLogged")
public class CityServletLogged extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String city_index = request.getParameter("cityIndex");
		ArrayList<City> cityList = (ArrayList<City>)request.getSession().getAttribute("ProcessSearchLogged");
		City city = cityList.get(Integer.parseInt(city_index));
		request.setAttribute("cityInfoObject", city);
		request.getRequestDispatcher("cityinfoLogged.jsp").forward(request, response);
		
	}

}
