

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/LoggedPreSearch")
public class LoggedPreSearch extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection conn = null;
		PreparedStatement ps = null;
		
		String userInputCity = null;
		String searchType = request.getParameter("searchType");
		String userName = (String) request.getSession().getAttribute("userName");
		System.out.println(userName);
		if (searchType.equals("a")) {
			userInputCity = request.getParameter("citySearchName");
			try {
				Class.forName("com.mysql.jdbc.Driver");
				conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/WeatherMeister?user=root&password=rootroot");
			    
				String query = "INSERT INTO WeatherSearches" 
						+ " (userName, searchValue)"
						+ " values (?,?)";
				ps = conn.prepareStatement(query);
				ps.setString(1, userName);
				ps.setString(2, userInputCity);
				int i = ps.executeUpdate();
				System.out.println(i);
				request.getRequestDispatcher("ProcessSearchLogged").forward(request, response);
				return;
			
			} catch (SQLException sqle) {
				System.out.println("sqle: " + sqle.getMessage());
			}  catch (ClassNotFoundException cnfe) {
				System.out.println("cnfe: " + cnfe.getMessage()); 
			}
		}
		else {
			String latSearch = request.getParameter("latSearch");
			String longSearch = request.getParameter("longSearch");
			String searchEntry = "("+latSearch+", "+longSearch+")";
			try {
				Class.forName("com.mysql.jdbc.Driver");
				conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/WeatherMeister?user=root&password=rootroot");
			    
				String query = "INSERT INTO WeatherSearches" 
						+ " (userName, searchValue)"
						+ " values (?,?)";
				ps = conn.prepareStatement(query);
				ps.setString(1, userName);
				ps.setString(2, searchEntry);
				int i = ps.executeUpdate();
				System.out.println(i);
				request.getRequestDispatcher("ProcessSearchLogged").forward(request, response);
				return;
			
			} catch (SQLException sqle) {
				System.out.println("sqle: " + sqle.getMessage());
			}  catch (ClassNotFoundException cnfe) {
				System.out.println("cnfe: " + cnfe.getMessage()); 
			}
		}
		
		
		
	}

}
