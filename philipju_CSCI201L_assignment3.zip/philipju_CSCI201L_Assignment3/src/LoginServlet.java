

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String userName= request.getParameter("UserName");
		String userPW = request.getParameter("UserPW");
		
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		// When a user is trying to log in
		// check their acct name with password
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/WeatherMeister?user=root&password=rootroot");
			String query =  "SELECT * FROM UserLogins WHERE userName = ?";
			ps = conn.prepareStatement(query);
			ps.setString(1, userName);
		    rs = ps.executeQuery();
		    while (rs.next()) {    	
	    		String dbuserPW = rs.getString("userPassword");
	    		if (dbuserPW != null && dbuserPW.equals(userPW)) {
	    			//successful login
	    			System.out.println("successful login");
	    			request.getSession().setAttribute("userName", userName);
	    			request.getRequestDispatcher("index2.jsp").forward(request, response);
	    			return;
	    		}
	    		else {
	    			//wrong password
	    			System.out.println("wrong password");
	    			String errormsg = "Incorrect password.";
	    			request.getSession().setAttribute("LoginServlet", errormsg);
	    			request.getRequestDispatcher("loginerror.jsp").forward(request, response);
	    			return;
	    		}
		    	
		    	
		    }
		    // username doesn't exist;
		    System.out.println("username doesnt exist");
		    String errormsg = "This user does not exist.";
		    request.getSession().setAttribute("LoginServlet", errormsg);
		    request.getRequestDispatcher("loginerror.jsp").forward(request, response);
		    return;
		} catch (SQLException sqle) {
			System.out.println("sqle: " + sqle.getMessage());
		}  catch (ClassNotFoundException cnfe) {
			System.out.println("cnfe: " + cnfe.getMessage()); 
		}
	}
}
