
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import csci201.City;
import csci201.CityData;

@WebServlet("/ProcessSearchLogged")
public class ProcessSearchLogged extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String userName = (String) request.getSession().getAttribute("userName");
		String API_KEY = "a45738a25fdaccdf72e38ddd0f231845";
		//searchType=a
		String userInputCity = null;
		String searchType = request.getParameter("searchType");
		ArrayList<City> cityList = new ArrayList<City>();
		
		if (searchType.equals("a")) {
			userInputCity = request.getParameter("citySearchName");
			System.out.println(userInputCity);
			//this code block brought from sandbox
			//String urlString = "http://api.openweathermap.org/data/2.5/weather?q=" + LOCATION + "&appid=" + API_KEY + "&units=imperial" ;
			//String urlString = 	"http://api.openweathermap.org/data/2.5/weather?id=2524884&APPID=" + API_KEY;			
			String filePath = getServletContext().getRealPath("/city.list.json");
			
			Gson gson = new Gson();
			Type collectionType = new TypeToken<Collection<CityData>>(){}.getType();
			Collection<CityData> citydata = gson.fromJson(new FileReader(filePath), collectionType);
			Iterator<CityData> iterator = citydata.iterator();
			ArrayList<Integer> cityIds = new ArrayList<Integer>();
			
			while (iterator.hasNext()) {
				CityData temp = iterator.next();
				if (temp.getName().equalsIgnoreCase(userInputCity)) {
					cityIds.add(temp.getId());
				}
			}
			for (int i = 0; i < cityIds.size(); i++) {
				try {
					System.out.println("Retrieving data for id " + cityIds.get(i));
					StringBuilder result = new StringBuilder();
					String urlString = 	"http://api.openweathermap.org/data/2.5/weather?id=" + cityIds.get(i)
							+ "&APPID=" + API_KEY + "&units=imperial";
					URL url = new URL(urlString);
					URLConnection conn = url.openConnection();
					BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
					String line;
					while ((line = rd.readLine()) != null) {
						result.append(line);
					}
					rd.close();

					String city = null;
					String latitude = null;
					String longitude = null;
					String sunriseTime = null;
					String sunsetTime = null;
					String currentTemperature = null;
					String dayLow = null;
					String dayHigh = null;
					String humidity = null;
					String pressure = null;
					String windspeed = null;
					
					Map<String, Object> respMap = jsonToMap(result.toString());
					Map<String, Object> coordMap = jsonToMap(respMap.get("coord").toString());
					Map<String, Object> mainMap = jsonToMap(respMap.get("main").toString());
					Map<String, Object> windMap = jsonToMap(respMap.get("wind").toString());
					Map<String, Object> sysMap = jsonToMap(respMap.get("sys").toString());
					
					city = userInputCity;
					latitude =  coordMap.get("lat").toString();
					longitude =  coordMap.get("lon").toString();
					sunriseTime =   sysMap.get("sunrise").toString();
					sunsetTime =  sysMap.get("sunset").toString();
					currentTemperature =  mainMap.get("temp").toString();
					dayLow = mainMap.get("temp_min").toString();
					dayHigh =  mainMap.get("temp_max").toString();
					humidity = mainMap.get("humidity").toString();
					pressure =  mainMap.get("pressure").toString();
					windspeed = windMap.get("speed").toString();
					
					// make a city if all of these constructor parameters are NOT null
					if (city != null &&
						latitude != null &&
						longitude != null &&
						sunriseTime != null &&
						sunsetTime != null &&
						currentTemperature != null &&
						dayLow != null &&
						dayHigh != null &&
						humidity != null &&
						pressure != null &&
						windspeed != null ) {
						String[] args = {city, latitude, longitude, sunriseTime, sunsetTime, currentTemperature, dayLow, dayHigh, humidity, pressure, windspeed };
						try {
							City nextcity = new City(args);
							cityList.add(nextcity);
							
						} catch (Exception e) {
							System.out.println("couldnt make the city for invalid arguments");
							// couldn't make the city for invalid arguments
							// just keep iterating through and return to next page
						}
					} 
					
				} catch (IOException e) {
					System.out.println(e.getMessage());
					// couldn't read the file or other error here
					// just return to next page
				}
				
			}

			request.getSession().setAttribute("ProcessSearchLogged", cityList);
			request.getRequestDispatcher("displayall2Logged.jsp").forward(request, response);
			return;
				
			}
			
		else if (searchType.equals("b")) {
			try {
				String latSearch = request.getParameter("latSearch");
				String longSearch = request.getParameter("longSearch");
				StringBuilder result = new StringBuilder();
				
				String urlString = 	"http://api.openweathermap.org/data/2.5/weather?lat=" + latSearch
						+ "&lon=" + longSearch
						+ "&APPID=" + API_KEY + "&units=imperial";
				URL url = new URL(urlString);
				URLConnection conn = url.openConnection();
				BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
				String line;
				while ((line = rd.readLine()) != null) {
					result.append(line);
				}
				rd.close();
				String city = null;
				String latitude = null;
				String longitude = null;
				String sunriseTime = null;
				String sunsetTime = null;
				String currentTemperature = null;
				String dayLow = null;
				String dayHigh = null;
				String humidity = null;
				String pressure = null;
				String windspeed = null;
				
				Map<String, Object> respMap = jsonToMap(result.toString());
				Map<String, Object> coordMap = jsonToMap(respMap.get("coord").toString());
				Map<String, Object> mainMap = jsonToMap(respMap.get("main").toString());
				Map<String, Object> windMap = jsonToMap(respMap.get("wind").toString());
				Map<String, Object> sysMap = jsonToMap(respMap.get("sys").toString());
				
				city = respMap.get("name").toString();
				latitude =  coordMap.get("lat").toString();
				longitude =  coordMap.get("lon").toString();
				sunriseTime =   sysMap.get("sunrise").toString();
				sunsetTime =  sysMap.get("sunset").toString();
				currentTemperature =  mainMap.get("temp").toString();
				dayLow = mainMap.get("temp_min").toString();
				dayHigh =  mainMap.get("temp_max").toString();
				humidity = mainMap.get("humidity").toString();
				pressure =  mainMap.get("pressure").toString();
				windspeed = windMap.get("speed").toString();
				// make a city if all of these constructor parameters are NOT null
				if (city != null &&
					latitude != null &&
					longitude != null &&
					sunriseTime != null &&
					sunsetTime != null &&
					currentTemperature != null &&
					dayLow != null &&
					dayHigh != null &&
					humidity != null &&
					pressure != null &&
					windspeed != null ) 
				{
					String[] args = {city, latitude, longitude, sunriseTime, sunsetTime, currentTemperature, dayLow, dayHigh, humidity, pressure, windspeed };
					try {
						City nextcity = new City(args);
						cityList.add(nextcity);
						System.out.println("Made the City object with lat/long search");
					} catch (Exception e) {
						System.out.println("couldnt make the city for invalid arguments");
						// couldn't make the city for invalid arguments
						// just keep iterating through and return to next page
					}
				}
				else {
					System.out.println("Something was null and couldn't make City object");
				}
				
				
			} catch (IOException e) {
				System.out.println(e.getMessage());
				// couldn't read the file or other error here
				// just return to next page
			}
		}
		else {
			// Not a city search nor a latlong search?
			System.out.println("Dev error: Neither a city search nor a lat/long search.");
			
		}

		request.getSession().setAttribute("ProcessSearchLogged", cityList);
		request.getRequestDispatcher("displayall2Logged.jsp").forward(request, response);
		return;
    }
	public static Map<String, Object> jsonToMap(String str) {
		Map<String, Object> map = new Gson().fromJson(
				str, new TypeToken<HashMap<String, Object>>() {}.getType()

				);
		return map;
	}
}
