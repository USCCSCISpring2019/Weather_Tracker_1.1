

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/ProfileServlet")
public class ProfileServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String userName = (String) request.getSession().getAttribute("userName");
		System.out.println(userName);
		// make the call to the DB
		// to get the resutset with all of the data in time order
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		ArrayList<String> searchHist = new ArrayList<String>();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/WeatherMeister?user=root&password=rootroot");
			String query =  "SELECT * FROM WeatherSearches WHERE userName = ?"
					+ " ORDER BY entry_time DESC";
			ps = conn.prepareStatement(query);
			ps.setString(1, userName);
		    rs = ps.executeQuery();
		    while (rs.next()) {    
		    	String nextSearch = rs.getString("searchValue");
		    	if (nextSearch.equals("")) {
		    		nextSearch = "NO ENTRY SEARCH";
		    	}
		    	searchHist.add(nextSearch);
	    	}
		    System.out.println("Returning a list of size " + searchHist.size());
		    request.setAttribute("ProfileServlet", searchHist);
		    request.getRequestDispatcher("profilepage.jsp").forward(request, response);
		    

		} catch (SQLException sqle) {
			System.out.println("sqle: " + sqle.getMessage());
		}  catch (ClassNotFoundException cnfe) {
			System.out.println("cnfe: " + cnfe.getMessage()); 
		}
	}



}
