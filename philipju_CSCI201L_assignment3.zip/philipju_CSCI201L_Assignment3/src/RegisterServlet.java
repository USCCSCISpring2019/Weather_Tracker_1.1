

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String userName = request.getParameter("UserName");
		String userPW1 = request.getParameter("UserPWorig");
		String userPW2 = request.getParameter("UserPWchek");
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		String errormsg = null;
		// if userpw1 and userpw2 not equal, send to error register
		if (!userPW1.equals(userPW2)) {
			errormsg = "The passwords do not match.";
			request.getSession().setAttribute("RegisterServlet", errormsg);
			request.getRequestDispatcher("registererror.jsp").forward(request, response);
			return;
		}
		else {
			// first see if that user already exist
			try {
				Class.forName("com.mysql.jdbc.Driver");
				conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/WeatherMeister?user=root&password=rootroot");
			    String query = "SELECT * FROM UserLogins WHERE userName = ?";
			    ps = conn.prepareStatement(query);
			    ps.setString(1, userName);
			    rs = ps.executeQuery();
			    while (rs.next()) {
			    	// if in here, then already username exists already
			    	errormsg = "This username is already taken.";
					request.getSession().setAttribute("RegisterServlet", errormsg);
					request.getRequestDispatcher("registererror.jsp").forward(request, response);
					return;
			    }
			    // now if here, lets create account
			    String query2 = "INSERT INTO UserLogins (userName, userPassword) VALUES (?,?)";
			    ps = conn.prepareStatement(query2);
			    ps.setString(1, userName);
			    ps.setString(2, userPW1);
			    int i = ps.executeUpdate();
			    System.out.println("Account created successfully!");
			    request.getSession().setAttribute("userName", userName);
    			request.getRequestDispatcher("index2.jsp").forward(request, response);
    			return;
			    
			} catch (SQLException sqle) {
				System.out.println("sqle: " + sqle.getMessage());
			}  catch (ClassNotFoundException cnfe) {
				System.out.println("cnfe: " + cnfe.getMessage()); 
			}
			
			
		}
	}


}
