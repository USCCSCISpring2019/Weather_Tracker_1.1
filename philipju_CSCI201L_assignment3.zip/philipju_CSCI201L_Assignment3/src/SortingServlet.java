

import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.*;

import csci201.City;

@WebServlet("/SortingServlet")
public class SortingServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String sortoption = request.getParameter("select123");
		System.out.println(sortoption.getClass());
		ArrayList<City> cityList = (ArrayList<City>)request.getSession().getAttribute("ProcessSearch");
		System.out.println(cityList.get(0).getCity());
		
		// sort alphabetically
		if (sortoption.equals("0")) {
			Collections.sort(cityList, new Comparator<City>(){
				public int compare(City c1, City c2) {
					return c1.getCity().compareTo(c2.getCity());
				} 
			}); 
		}
		// sort reverse alphabetically
		else if (sortoption.equals("1")) {
			Collections.sort(cityList, new Comparator<City>(){
				public int compare(City c1, City c2) {
					return c1.getCity().compareTo(c2.getCity());
				} 
			});
			Collections.reverse(cityList);
		}
		else if (sortoption.equals("2")) {
			Collections.sort(cityList, new Comparator<City>(){
				@Override public int compare(City c1, City c2) {
					return c1.getDayLow() - c2.getDayLow();
				} 
			});
		}
		else if (sortoption.equals("3")) {
			Collections.sort(cityList, new Comparator<City>(){
				@Override public int compare(City c1, City c2) {
					return c1.getDayLow() - c2.getDayLow();
				} 
			});
			Collections.reverse(cityList);
		}
		else if (sortoption.equals("4")) {
			Collections.sort(cityList, new Comparator<City>(){
				@Override public int compare(City c1, City c2) {
					return c1.getDayHigh() - c2.getDayHigh();
				} 
			});
		} else {	
			Collections.sort(cityList, new Comparator<City>(){
				@Override public int compare(City c1, City c2) {
					return c1.getDayHigh() - c2.getDayHigh();
				} 
			});
			Collections.reverse(cityList);
		}
		
		request.getRequestDispatcher("displayall3.jsp").forward(request, response);
	}

}
