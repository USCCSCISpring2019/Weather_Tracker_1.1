package csci201;

public class City  {
	
	/*
	 * city|state|country|latitude|longitude|sunrise|sunset|currentTemp
erature|dayLow|dayHigh|humidity|pressure|visibility|windSpeed|wi
ndDirection|conditionDescription1|conditionDescription2|...|cond
itionDescriptionN

	 */
	
	private String city;
	private double latitude;
	private double longitude;
	private String sunriseTime;
	private String sunsetTime;
	private double currentTemperature;
	private double dayLow;
	private double dayHigh;
	private double humidity;
	private double pressure;
	private double windspeed;
	
	// Constructor that takes an array of Strings as arg
	public City(String[] cityInfo) throws MyException {
		city = cityInfo[0];
		latitude = myDoubleParser(cityInfo[1]);
		longitude = myDoubleParser(cityInfo[2]);
		sunriseTime = (cityInfo[3]);
		sunsetTime = (cityInfo[4]);
		currentTemperature = myDoubleParser(cityInfo[5]);
		dayLow = myDoubleParser(cityInfo[6]);
		dayHigh =  myDoubleParser(cityInfo[7]);
		humidity = myDoubleParser(cityInfo[8]);
		pressure = myDoubleParser(cityInfo[9]);
		windspeed = myDoubleParser(cityInfo[10]);
	}
	public String getCity() {
		if (city.equals("")) return "NO NAME GIVEN";
		return toTitleCase(city);
	}
	public String getLatitude() {
		String latStr = String.format("%.4f", latitude);
		return latStr;
	}
	public String getLongitude() {
		String lonStr = String.format("%.4f", longitude);
		return lonStr;
	}
	public String getSunriseTime() {
		return sunriseTime;
	}
	public String getSunsetTime() {
		return sunsetTime;
	}
	public double getCurrentTemperature() {
		return currentTemperature;
	}
	public int getDayLow() {
		return (int)dayLow;
	}
	public int getDayHigh() {
		return (int)dayHigh;
	}
	public double getHumidity() {
		return humidity;
	}
	public double getPressure() {
		return pressure;
	}
	public double getWindspeed() {
		return windspeed;
	}
	public static String toTitleCase(String givenString) {
	    String[] arr = givenString.split(" ");
	    StringBuffer sb = new StringBuffer();

	    for (int i = 0; i < arr.length; i++) {
	        sb.append(Character.toUpperCase(arr[i].charAt(0)))
	            .append(arr[i].substring(1)).append(" ");
	    }          
	    return sb.toString().trim();
	}  
	private static double myDoubleParser(String arg) throws MyException {
		double coord;
		try {
			coord = Double.parseDouble(arg);
		}
		catch (NumberFormatException e) {
			throw new MyException(arg, "double");
		}
		return coord;
	}
	
	
	private static int myIntParser(String arg) throws MyException {
		int temp;
		try {
			temp = Integer.parseInt(arg);
		}
		catch (NumberFormatException e) {
			throw new MyException(arg, "integer");
		}
		return temp;
	}
	private static float myFloatParser(String arg) throws MyException {
		float temp;
		try {
			temp = Float.parseFloat(arg);
		}
		catch (NumberFormatException e) {
			throw new MyException(arg, "float");
		}
		return temp;
	}
	
	// Just don't want only white-space strings from being entered into description
	private static String myDescriptionParser(String arg) throws MyException{
		if (arg.trim().length() == 0) throw new MyException(arg, "string");
		return arg;
	}
}
	
