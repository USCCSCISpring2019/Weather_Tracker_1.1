package csci201;
public class CityData {
	private int id;
	private String name;
	private String country;
	public class coord {
		private double lon;
		private double lat;
		public coord(double lon, double lat) {
			this.lon = lon;
			this.lat = lat;
		}
	}
	
	public CityData(int id, String name, String country) {
		this.id = id;
		this.name = name;
		this.country = country;
	}
	public String getName() {
		return name;
	}
	public int getId() {
		return id;
	}
	public String print() {
		return "id = " + id + "name = " + name + "country = " + country;
	}
}
