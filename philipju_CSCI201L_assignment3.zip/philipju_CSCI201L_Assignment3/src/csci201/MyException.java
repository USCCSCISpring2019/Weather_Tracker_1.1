package csci201;

public class MyException extends Exception {
	
	// Compiler complains without serialVersionUID declared
	private static final long serialVersionUID = 1L;
	String arg, primitiveType;
	
	public MyException() {
		// This constructor does not initialize primitiveType
		// and will only be used to catch for erroneous inputs
		// when selecting from Menu class.
	}
	
	public MyException(String arg, String primitiveType) {
		this.arg = arg;
		this.primitiveType = primitiveType;
	}
	
	@Override
	public String getMessage() {
		String msg;
		if (primitiveType.equalsIgnoreCase("integer")) {
			msg = "Unable to convert '" + arg + "' to an " + primitiveType + ".";
		}
		else if (primitiveType.equalsIgnoreCase("float")) {
			msg = "Unable to convert '" + arg + "' to a " + primitiveType + ".";
		}
		else if (primitiveType.equalsIgnoreCase("string")) {
			msg = "The description cannot be all whitespace.";
		}
		else if (primitiveType.equalsIgnoreCase("double")) {
			msg = "Unable to convert '" + arg + "' to a " + primitiveType + ".";
		}
		else {
			// Message for erroneous menu selection
			msg = "That is not a valid option.\n";
		}
		return msg;
	}
}
